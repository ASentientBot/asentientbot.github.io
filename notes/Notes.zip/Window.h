@interface Window:NSWindow<NSTextViewDelegate>

@property(assign) NSTextView* text;
@property(assign) NSTextView* counter;

@end

#import "Window.m"