@interface Window:NSWindow<NSTextViewDelegate>

@property(assign) NSTextView* text;
@property(assign) NSTextView* counter;
@property(assign) NSScrollView* scroll;

@end

#import "Window.m"