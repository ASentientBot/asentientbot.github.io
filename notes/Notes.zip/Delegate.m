#import "Window.h"

long lastTriggerTime;

CGEventRef eventCallback(CGEventTapProxy proxy,CGEventType type,CGEventRef event,void* userInfo)
{
	Delegate* delegate=userInfo;
	return [delegate processEvent:event];
}

@implementation Delegate

-(void)showWindow
{
	self.window=Window.alloc.init;
	[NSNotificationCenter.defaultCenter addObserver:self selector:@selector(hideWindow) name:NSWindowDidResignKeyNotification object:self.window];
	[NSApp activateIgnoringOtherApps:true];
}

-(void)hideWindow
{
	self.window.close;
	self.window=nil;
}

-(CGEventRef)processEvent:(CGEventRef)event
{
	long keyCode=CGEventGetIntegerValueField(event,kCGKeyboardEventKeycode);
	if(keyCode==KEY_TRIGGER)
	{
		long triggerTime=CGEventGetTimestamp(event);
		
		// TODO: close on key-up if held, like Dashboard did
		
		if((triggerTime-lastTriggerTime)>NSEC_PER_SEC*FADE_TIME)
		{
			self.window?self.hideWindow:self.showWindow;
			lastTriggerTime=triggerTime;
		}
		
		return nil;
	}
	
	return event;
}

-(void)applicationDidFinishLaunching:(NSNotification*)notification
{
	if(!AXIsProcessTrusted())
	{
		NSAlert* alert=NSAlert.alloc.init;
		alert.alertStyle=NSAlertStyleCritical;
		alert.messageText=(NSString*)PERM_TITLE;
		alert.informativeText=(NSString*)PERM_DETAIL;
		
		[NSApp activateIgnoringOtherApps:true];
		
		alert.runModal;
		
		[NSApp terminate:nil];
	}
	
	NSApp.activationPolicy=NSApplicationActivationPolicyAccessory;
	
	lastTriggerTime=0;
	
	CFMachPortRef tapPort=CGEventTapCreate(kCGSessionEventTap,kCGHeadInsertEventTap,kCGEventTapOptionDefault,CGEventMaskBit(kCGEventKeyDown),eventCallback,self);
	CFRunLoopSourceRef tapSource=CFMachPortCreateRunLoopSource(NULL,tapPort,0);
	CFRunLoopAddSource(CFRunLoopGetMain(),tapSource,kCFRunLoopDefaultMode);
	
	NSMenu* menu=NSMenu.alloc.init;
	
	NSMenu* editMenu=NSMenu.alloc.init;
	[editMenu addItemWithTitle:@"" action:@selector(selectAll:) keyEquivalent:@"a"];
	[editMenu addItemWithTitle:@"" action:@selector(cut:) keyEquivalent:@"x"];
	[editMenu addItemWithTitle:@"" action:@selector(copy:) keyEquivalent:@"c"];
	[editMenu addItemWithTitle:@"" action:@selector(paste:) keyEquivalent:@"v"];
	[editMenu addItemWithTitle:@"" action:@selector(undo:) keyEquivalent:@"z"];
	NSMenuItem* redoItem=[editMenu addItemWithTitle:@"" action:@selector(redo:) keyEquivalent:@"z"];
	redoItem.keyEquivalentModifierMask|=NSEventModifierFlagShift;
	NSMenuItem* findItem=[editMenu addItemWithTitle:@"" action:@selector(performTextFinderAction:) keyEquivalent:@"f"];
	findItem.tag=NSTextFinderActionShowFindInterface;
	NSMenuItem* findNextItem=[editMenu addItemWithTitle:@"" action:@selector(performTextFinderAction:) keyEquivalent:@"g"];
	findNextItem.tag=NSTextFinderActionNextMatch;
	NSMenuItem* findPrevItem=[editMenu addItemWithTitle:@"" action:@selector(performTextFinderAction:) keyEquivalent:@"g"];
	findPrevItem.keyEquivalentModifierMask|=NSEventModifierFlagShift;
	findPrevItem.tag=NSTextFinderActionPreviousMatch;
	[editMenu addItemWithTitle:@"" action:@selector(quit) keyEquivalent:@"q"];
	
	NSMenuItem* editItem=[menu addItemWithTitle:@"" action:nil keyEquivalent:@""];
	[menu setSubmenu:editMenu forItem:editItem];
	
	NSApp.mainMenu=menu;
}

-(void)quit
{
	self.hideWindow;
	[NSApp terminate:nil];
}

@end