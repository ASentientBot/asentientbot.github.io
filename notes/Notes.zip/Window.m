@implementation Window

-(instancetype)init
{
	NSScreen* screen=NSScreen.mainScreen;
	
	self=[super initWithContentRect:screen.frame styleMask:0 backing:NSBackingStoreBuffered defer:false screen:screen];
	self.level=NSScreenSaverWindowLevel;
	
	NSRect rect=NSMakeRect(0,0,screen.frame.size.width,screen.frame.size.height);
	
	NSVisualEffectView* blur=[NSVisualEffectView.alloc initWithFrame:rect];
	blur.material=NSVisualEffectMaterialSheet;
	self.contentView=blur;
	
	NSScrollView* scroll=[NSScrollView.alloc initWithFrame:rect];
	scroll.drawsBackground=false;
	scroll.hasVerticalScroller=true;
	[self.contentView addSubview:scroll];
	self.scroll=scroll;
	
	NSTextView* text=[NSTextView.alloc initWithFrame:rect];
	text.drawsBackground=false;
	text.font=[NSFont systemFontOfSize:FONT_SIZE];
	text.richText=false;
	text.allowsUndo=true;
	text.usesFindBar=true;
	text.delegate=self;
	scroll.documentView=text;
	self.text=text;
	
	NSRect counterRect=NSMakeRect(rect.size.width-COUNTER_WIDTH,0,COUNTER_WIDTH,0);
	NSTextView* counter=[NSTextView.alloc initWithFrame:counterRect];
	counter.drawsBackground=false;
	[counter alignRight:nil];
	counter.font=[NSFont systemFontOfSize:FONT_SIZE];
	counter.editable=false;
	counter.selectable=false;
	counter.alphaValue=COUNTER_ALPHA;
	[self.contentView addSubview:counter];
	self.counter=counter;
	
	NSMutableParagraphStyle* style=NSMutableParagraphStyle.alloc.init;
	double tabSpacing=style.tabStops[0].location;
	NSMutableArray* tabs=NSMutableArray.alloc.init;
	for(int i=0;i<TAB_COUNT;i++)
	{
		NSTextTab* tab=[NSTextTab.alloc initWithTextAlignment:NSTextAlignmentLeft location:i*tabSpacing options:@{}];
		[tabs addObject:tab];
	}
	style.tabStops=tabs;
	style.lineBreakMode=NSLineBreakByCharWrapping;
	text.defaultParagraphStyle=style;
	
	self.loadText;
	self.updateCounter;
	
	self.alphaValue=0;
	NSAnimationContext.beginGrouping;
	NSAnimationContext.currentContext.duration=FADE_TIME;
	self.animator.alphaValue=1;
	NSAnimationContext.endGrouping;
	
	[self makeKeyAndOrderFront:nil];
	
	return self;
}

-(BOOL)canBecomeKeyWindow
{
	return true;
}

-(void)close
{
	self.saveText;
	
	NSAnimationContext.beginGrouping;
	NSAnimationContext.currentContext.duration=FADE_TIME;
	NSAnimationContext.currentContext.completionHandler=^()
	{
		super.close;
	};
	self.animator.alphaValue=0;
	NSAnimationContext.endGrouping;
}

-(void)loadText
{
	NSString* text=[NSUserDefaults.standardUserDefaults stringForKey:(NSString*)KEY_TEXT];
	if(text)
	{
		self.text.string=text;
	}
	else
	{
		self.text.string=(NSString*)WELCOME_TEXT;
	}
	
	NSArray<NSArray<NSNumber*>*>* selectionsIn=[NSUserDefaults.standardUserDefaults objectForKey:(NSString*)KEY_SELECTIONS];
	if(selectionsIn&&selectionsIn.count>0)
	{
		NSMutableArray<NSValue*>* selectionsOut=NSMutableArray.alloc.init;
		for(int i=0;i<selectionsIn.count;i++)
		{
			NSRange range=NSMakeRange(selectionsIn[i][0].longValue,selectionsIn[i][1].longValue);
			NSValue* value=[NSValue valueWithRange:range];
			[selectionsOut addObject:value];
		}
		self.text.selectedRanges=selectionsOut;
		
		[self.text scrollRangeToVisible:selectionsOut[0].rangeValue];
	}
}

-(void)saveText
{
	[NSUserDefaults.standardUserDefaults setObject:self.text.string forKey:(NSString*)KEY_TEXT];
	
	NSArray<NSValue*>* selectionsIn=self.text.selectedRanges;
	NSMutableArray<NSArray<NSNumber*>*>* selectionsOut=NSMutableArray.alloc.init;
	for(int i=0;i<selectionsIn.count;i++)
	{
		NSNumber* start=[NSNumber numberWithLong:selectionsIn[i].rangeValue.location];
		NSNumber* length=[NSNumber numberWithLong:selectionsIn[i].rangeValue.length];
		[selectionsOut addObject:@[start,length]];
	}
	[NSUserDefaults.standardUserDefaults setObject:selectionsOut forKey:(NSString*)KEY_SELECTIONS];
}

-(void)textDidChange:(NSNotification*)notification
{
	self.updateCounter;
}

-(void)updateCounter
{
	// https://developer.apple.com/library/archive/documentation/Cocoa/Conceptual/TextLayout/Tasks/CountLines.html
	
	int lineCount=0;
	int index=0;
	NSString* string=self.text.string;
	while(index<string.length)
	{
		index=NSMaxRange([string lineRangeForRange:NSMakeRange(index,0)]);
		lineCount++;
	}
	
	self.counter.string=[NSString stringWithFormat:@"%d",lineCount];
}

@end