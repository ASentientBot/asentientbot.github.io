@import AppKit;

const int KEY_TRIGGER=130;
const float FADE_TIME=0.3;
const float FONT_SIZE=14;
const int TAB_COUNT=100;
const float COUNTER_WIDTH=50;
const float COUNTER_ALPHA=0.5;
const NSString* KEY_TEXT=@"text";
const NSString* KEY_SELECTIONS=@"selections";
const NSString* WELCOME_TEXT=@"type notes here\nuse Dashboard key to show/hide\nauto-saves on close";
const NSString* PERM_TITLE=@"can't listen for Dashboard key";
const NSString* PERM_DETAIL=@"allow \"Accessibility\" access in \"Security & Privacy\" preferences, then re-launch";

#import "Delegate.h"

int main(int argCount,char** argList)
{
	NSApplication.sharedApplication.delegate=Delegate.alloc.init;
	NSApp.run;
	
	return 0;
}