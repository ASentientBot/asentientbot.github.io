@class Window;

@interface Delegate:NSObject<NSApplicationDelegate>

@property(retain) Window* window;

-(CGEventRef)processEvent:(CGEventRef)event;

@end

#import "Delegate.m"