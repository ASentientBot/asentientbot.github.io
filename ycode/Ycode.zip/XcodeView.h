#import "XcodeViewSettings.h"

#import "XcodeInterfaces.m"
#import "XcodeWrapAnywhereTypesetter.m"

@interface XcodeView:DVTSourceTextScrollView

@property DVTTextStorage* codeStorage;
@property DVTSourceTextView* codeView;

-(instancetype)initWithFrame:(NSRect)rect;
-(void)guessLanguageFromURL:(NSURL*)codeURL;
-(void)loadURL:(NSURL*)codeURL;
-(void)loadString:(NSString*)codeString;
-(void)saveURL:(NSURL*)codeURL;
-(NSString*)string;
-(void)undo;
-(void)redo;

@end


#import "XcodeView.m"