@interface AppDelegate:NSObject<NSApplicationDelegate>
@end

#import "AppDelegate.m"